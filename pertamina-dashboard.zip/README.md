# Pertamina Operation Dashboard (Vite + React) - Demo

Quickstart:
1. npm install
2. npm run start
Frontend: http://localhost:5173
Mock API: http://localhost:3001
