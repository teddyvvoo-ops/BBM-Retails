import React, { useEffect, useState, useRef } from "react";
import { motion } from "framer-motion";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

async function fetchDashboardData({ tanggal, produk }) {
  const res = await fetch(`/api/dashboard?tanggal=${tanggal}&produk=${produk}`);
  if (!res.ok) throw new Error('Fetch error');
  return res.json();
}

function exportCSV(filename, rows) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export default function PertaminaDashboard() {
  const [tanggal, setTanggal] = useState(() => new Date().toISOString().slice(0,10));
  const [produk, setProduk] = useState("all");
  const [stok, setStok] = useState([]);
  const [sales, setSales] = useState([]);
  const [losist, setLosist] = useState([]);
  const [meta, setMeta] = useState({ total_stok: 0, sales_today: 0, projects: 0 });
  const [autoRefresh, setAutoRefresh] = useState(true);
  const intervalRef = useRef(null);

  const loadData = async () => {
    try {
      const res = await fetchDashboardData({ tanggal, produk });
      setStok(res.stok);
      setSales(res.sales);
      setLosist(res.losist);
      setMeta(res.meta);
    } catch(e) {
      console.error(e);
    }
  };

  useEffect(()=>{ loadData(); }, [tanggal, produk]);

  useEffect(()=>{
    if(!autoRefresh){ if(intervalRef.current) clearInterval(intervalRef.current); return; }
    intervalRef.current = setInterval(()=>loadData(), 30000);
    return ()=> clearInterval(intervalRef.current);
  }, [autoRefresh, tanggal, produk]);

  const handleExportStok = () => {
    const rows = [["Jenis BBM","Stok"]].concat(stok.map(s=>[s.name,s.value]));
    exportCSV("stok_bbm.csv", rows);
  };
  const handleExportSales = () => {
    const rows = [["Hari","Penjualan"]].concat(sales.map(s=>[s.name,s.value]));
    exportCSV("sales_harian.csv", rows);
  };

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-[#d7141a] via-[#b80f15] to-[#67080c] text-white">
      <aside className="w-64 p-6 border-r border-white/10">
        <h2 className="text-xl font-bold mb-6">PERTAMINA</h2>
        <nav className="space-y-3 text-sm opacity-90">
          <button className="w-full text-left px-3 py-2 rounded-lg bg-white/5">Dashboard Utama</button>
          <button className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5">Stok BBM</button>
          <button className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5">Sales</button>
        </nav>

        <div className="mt-6">
          <p className="text-xs opacity-80">Filters</p>
          <div className="mt-2 space-y-2">
            <input type="date" value={tanggal} onChange={(e)=>setTanggal(e.target.value)} className="w-full rounded-md bg-white/10 py-2 px-3" />
            <select className="w-full rounded-md bg-white/10 py-2 px-3" value={produk} onChange={(e)=>setProduk(e.target.value)}>
              <option value="all">Semua Produk</option>
              <option value="premium">Premium</option>
              <option value="pertalite">Pertalite</option>
              <option value="pertamax">Pertamax</option>
              <option value="solar">Solar</option>
            </select>
            <div className="flex items-center gap-2">
              <input id="auto" type="checkbox" checked={autoRefresh} onChange={(e)=>setAutoRefresh(e.target.checked)} />
              <label htmlFor="auto" className="text-sm opacity-80">Auto-refresh (30s)</label>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <button onClick={handleExportStok} className="w-full mb-2 px-3 py-2 rounded bg-white/10">Export Stok</button>
          <button onClick={handleExportSales} className="w-full px-3 py-2 rounded bg-white/10">Export Sales</button>
        </div>
      </aside>

      <main className="flex-1 p-6 overflow-auto">
        <motion.header initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <h1 className="text-3xl font-bold mb-4">Operation Dashboard</h1>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-white/10 p-4 rounded">
              <p className="text-sm opacity-80">Total Stok</p>
              <h2 className="text-2xl font-bold">{meta.total_stok} L</h2>
            </div>
            <div className="bg-white/10 p-4 rounded">
              <p className="text-sm opacity-80">Sales Hari Ini</p>
              <h2 className="text-2xl font-bold">{meta.sales_today} L</h2>
            </div>
            <div className="bg-white/10 p-4 rounded">
              <p className="text-sm opacity-80">Lossist</p>
              <h2 className="text-2xl font-bold">Turun</h2>
            </div>
            <div className="bg-white/10 p-4 rounded">
              <p className="text-sm opacity-80">Project Aktif</p>
              <h2 className="text-2xl font-bold">{meta.projects}</h2>
            </div>
          </div>
        </motion.header>

        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white/10 p-4 rounded">
            <h3 className="font-semibold mb-2">Stok BBM Harian</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stok}>
                  <XAxis dataKey="name" stroke="#fff" />
                  <YAxis stroke="#fff" />
                  <Tooltip />
                  <Bar dataKey="value" fill="#00eaff" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white/10 p-4 rounded">
            <h3 className="font-semibold mb-2">Sales Harian</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sales}>
                  <XAxis dataKey="name" stroke="#fff" />
                  <YAxis stroke="#fff" />
                  <Tooltip />
                  <Bar dataKey="value" fill="#ffdd57" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white/10 p-4 rounded">
            <h3 className="font-semibold mb-2">Losist Harian</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={losist}>
                  <Area type="monotone" dataKey="nilai" strokeWidth={2} />
                  <XAxis dataKey="tanggal" stroke="#fff" />
                  <YAxis stroke="#fff" />
                  <Tooltip />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
