import React from 'react';
import PertaminaDashboard from './components/PertaminaDashboard';
export default function App(){ return <PertaminaDashboard />; }
