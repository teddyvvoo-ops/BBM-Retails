const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/dashboard', (req, res) => {
  const stok = [
    { name: 'Premium', value: 1200 },
    { name: 'Pertalite', value: 4300 },
    { name: 'Pertamax', value: 2800 },
    { name: 'Solar', value: 780 },
  ];
  const sales = [
    { name: 'Senin', value: 120 },
    { name: 'Selasa', value: 98 },
    { name: 'Rabu', value: 140 },
    { name: 'Kamis', value: 160 },
    { name: 'Jumat', value: 195 },
  ];
  const losist = [
    { tanggal: '2025-01-01', nilai: 12 },
    { tanggal: '2025-01-02', nilai: 8 },
  ];
  const meta = { total_stok: 7430, sales_today: 195, projects: 4 };
  res.json({ stok, sales, losist, meta });
});

const port = process.env.PORT || 3001;
app.listen(port, () => console.log('Mock API running on port', port));
