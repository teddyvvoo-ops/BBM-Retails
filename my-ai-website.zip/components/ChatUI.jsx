export default function ChatUI() {
  return <div>Chat UI</div>;
}