export default function Page() {
  return <div>Hello AI Web</div>;
}